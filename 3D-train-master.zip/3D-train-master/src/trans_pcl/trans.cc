
#include <pcl/io/pcd_io.h>
#include <pcl/common/transforms.h>
#include <pcl/visualization/pcl_visualizer.h>
 
int
main(int argc, char** argv)
{
	ifstream ifs("trans_matrix.txt");
	int line_count = 0;
	char buffer[100];
	while (! ifs.eof() ) { 
		ifs.getline (buffer,100);
		line_count++;
	}
	ifs.seekg (0, ios::beg);
	ifs.close();
	printf("line_cout = %d\n", line_count);
		
	int num_keyframes = line_count/4;
	printf("num_keyframes = %d\n", num_keyframes);

	for (int i = 0; i < num_keyframes; i ++) {
		char name[25] = {0};
		sprintf(name, "%d.points", i+1);
		printf("name = %s\n", name);
		ifstream ifs(name);
		if (!ifs) {
		    std::cout << "Open error\n";
		}
		int line_count = 0;
		char buffer[100];
		while (! ifs.eof() ) { 
		    ifs.getline (buffer,100);
		    line_count++;
		}
		ifs.seekg (0, ios::beg);
		ifs.close();
		printf("line_cout = %d\n", line_count);
		  pcl::PointCloud<pcl::PointXYZRGBA> cloud;

		  // Fill in the cloud data
		  cloud.width    = line_count;
		  cloud.height   = 1;
		  cloud.is_dense = false;
		  cloud.points.resize (cloud.width * cloud.height);

		  FILE *fp = fopen(name, "r");

		  int num;
		  float x,y,z;
		  int r,g,b,a;
		  for (size_t i = 0; i < cloud.points.size (); ++i)
		  {

			fscanf(fp, "%d,%f,%f,%f,%d,%d,%d,%d\n", &num,&x,&y,&z,&r,&g,&b,&a); 
		      cloud.points[i].x = x;
		      cloud.points[i].y = y;
		      cloud.points[i].z = z;
		      cloud.points[i].b = b&0xff;
		      cloud.points[i].g = g&0xff;
		      cloud.points[i].r = r&0xff;
		      cloud.points[i].a = 0;

		  }
			char sname[5] = {0};
			sprintf(sname, "%d.pcd", i+1); 
		  pcl::io::savePCDFileASCII (sname, cloud);

	}
 
	FILE *fp = fopen("trans_matrix.txt", "r");
	int i = 0;
	float tr[16*(num_keyframes)] = {0.0};
	int j = 0;
	char test[100];
	float a,b,c,d;
#if 1
	while (!feof(fp)) {
		i ++;
		//printf("i = %d\n", i);
			fscanf(fp, "%f,%f,%f,%f\n", &a,&b,&c,&d);	
			tr[j++] = a;
			tr[j++] = b;
			tr[j++] = c;
			tr[j++] = d;

	}
#endif

	Eigen::Matrix4f trans[num_keyframes] = {Eigen::Matrix4f::Identity()};
	for (int i = 0; i < num_keyframes; i++) {
		for (int j = 0; j < 16; j++) {
			trans[i](0,0) = tr[0+16*(i)];
			trans[i](0,1) = tr[1+16*(i)];
			trans[i](0,2) = tr[2+16*(i)];
			trans[i](0,3) = tr[3+16*(i)];
			trans[i](1,0) = tr[4+16*(i)];
			trans[i](1,1) = tr[5+16*(i)];
			trans[i](1,2) = tr[6+16*(i)];
			trans[i](1,3) = tr[7+16*(i)];
			trans[i](2,0) = tr[8+16*(i)];
			trans[i](2,1) = tr[9+16*(i)];
			trans[i](2,2) = tr[10+16*(i)];
			trans[i](2,3) = tr[11+16*(i)];
			trans[i](3,0) = tr[12+16*(i)];
			trans[i](3,1) = tr[13+16*(i)];
			trans[i](3,2) = tr[14+16*(i)];
			trans[i](3,3) = tr[15+16*(i)];
		}
	}
	

	//pcl::PointCloud<pcl::PointXYZ>::Ptr cloud[8] = {(new pcl::PointCloud<pcl::PointXYZ>)};
	pcl::PointCloud<pcl::PointXYZRGBA>* cloud[num_keyframes];
	for (int i = 0; i < num_keyframes; i++) {
		cloud[i] = new pcl::PointCloud<pcl::PointXYZRGBA>;
		char name[5] = {0};
		sprintf(name, "%d.pcd", i+1);
		printf("%s,%d, %s\n", __func__, __LINE__, name);
		pcl::io::loadPCDFile<pcl::PointXYZRGBA>(std::string(name), *(cloud[i]));
		Eigen::Matrix4f transM = Eigen::Matrix4f::Identity();
#if 0	
		transM = trans[0];
		for (int j = 1; j <= i; j++) {
			transM *= trans[j];
		}
#else		
		transM = trans[i];
		//if (i >= 1) {
		//	transM = trans[i-1];
		//}
#endif
		std::cout << transM << std::endl;
		pcl::PointCloud<pcl::PointXYZRGBA>::Ptr tranP(new pcl::PointCloud<pcl::PointXYZRGBA>);
		pcl::transformPointCloud(*cloud[i], *tranP, transM);
		char sname[5] = {0};
		sprintf(sname, "s%d.pcd", i+1);
		printf("%s,%d, %s\n", __func__, __LINE__, sname);
		pcl::io::savePCDFileASCII (std::string(sname), *tranP);
	}

#if 0
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud1(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::PointCloud<pcl::PointXYZ>::Ptr transformed1(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::io::loadPCDFile<pcl::PointXYZ>("2.pcd", *cloud1);
	pcl::transformPointCloud(*cloud1, *transformed1, transformation*transformation1);
	pcl::io::savePCDFileASCII ("b2.pcd", *transformed1);
#endif
 
#if 0
	// Visualize both the original and the result.
	pcl::visualization::PCLVisualizer viewer("1.pcd");
	viewer.addPointCloud(cloud[0], "original");
	// The transformed one's points will be red in color.
	pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> colorHandler(tranP[0], 255, 0, 0);
	viewer.addPointCloud(tranP[0], colorHandler, "transformed");
	// Add 3D colored axes to help see the transformation.
	viewer.addCoordinateSystem(1.0, 0);
 
	while (!viewer.wasStopped())
	{
		viewer.spinOnce();
	}
#endif
}

