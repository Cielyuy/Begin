
"use strict";

let keyframeMsg = require('./keyframeMsg.js');

module.exports = {
  keyframeMsg: keyframeMsg,
};
